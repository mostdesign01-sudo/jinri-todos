(function (root) {
const STORAGE_KEY = "jinri-todos-v1";
const DATA_VERSION = 2;
const TZ = "Asia/Shanghai";
const PRIORITIES = [
  { id: "urgent", label: "紧急", rank: 0 },
  { id: "high", label: "高", rank: 1 },
  { id: "medium", label: "中", rank: 2 },
  { id: "low", label: "低", rank: 3 },
];
const WEEKDAYS = ["一", "二", "三", "四", "五", "六", "日"];

function shanghaiDateStr(now) {
  return (now || new Date()).toLocaleDateString("en-CA", { timeZone: TZ });
}

function isDateStr(s) {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function dateFromStr(dateStr) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12));
}

function pad2(n) {
  return String(n).padStart(2, "0");
}

function toDateStr(y, m, d) {
  return y + "-" + pad2(m) + "-" + pad2(d);
}

function yearMonth(dateStr) {
  const [y, m] = (dateStr || shanghaiDateStr()).split("-").map(Number);
  return { y, m };
}

function addDays(dateStr, delta) {
  const day = isDateStr(dateStr) ? dateStr : shanghaiDateStr();
  const dt = dateFromStr(day);
  dt.setUTCDate(dt.getUTCDate() + Number(delta || 0));
  return toDateStr(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
}

function addMonths(year, month, delta) {
  const dt = new Date(Date.UTC(year, month - 1 + Number(delta || 0), 1));
  return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1 };
}

function formatHeaderDate(dateStr) {
  const dt = dateFromStr(isDateStr(dateStr) ? dateStr : shanghaiDateStr());
  return dt.toLocaleDateString("zh-CN", {
    timeZone: "UTC",
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

function formatShortDate(dateStr) {
  const day = isDateStr(dateStr) ? dateStr : shanghaiDateStr();
  const [, m, d] = day.split("-").map(Number);
  return m + "月" + d + "日";
}

function formatMonthTitle(year, month) {
  return year + "年" + month + "月";
}

function weekCells(dateStr) {
  const day = isDateStr(dateStr) ? dateStr : shanghaiDateStr();
  const dt = dateFromStr(day);
  const mondayOffset = (dt.getUTCDay() + 6) % 7;
  const monday = addDays(day, -mondayOffset);
  const viewMonth = yearMonth(day).m;
  return Array.from({ length: 7 }, (_, i) => {
    const date = addDays(monday, i);
    const parts = yearMonth(date);
    const d = Number(date.slice(-2));
    return { date, day: d, outside: parts.m !== viewMonth, y: parts.y, m: parts.m };
  });
}

function monthCells(year, month) {
  const firstWeekday = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
  const mondayOffset = (firstWeekday + 6) % 7;
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const prevMonthDays = new Date(Date.UTC(year, month - 1, 0)).getUTCDate();
  const cells = [];
  for (let i = 0; i < 42; i++) {
    let y = year;
    let m = month;
    let d;
    let outside = false;
    if (i < mondayOffset) {
      d = prevMonthDays - mondayOffset + i + 1;
      m = month - 1;
      if (m < 1) {
        m = 12;
        y -= 1;
      }
      outside = true;
    } else if (i >= mondayOffset + daysInMonth) {
      d = i - mondayOffset - daysInMonth + 1;
      m = month + 1;
      if (m > 12) {
        m = 1;
        y += 1;
      }
      outside = true;
    } else {
      d = i - mondayOffset + 1;
    }
    cells.push({ date: toDateStr(y, m, d), day: d, outside, y, m });
  }
  if (cells.slice(35).every((c) => c.outside)) cells.length = 35;
  return cells;
}

function uid() {
  return crypto.randomUUID ? crypto.randomUUID() : "t-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
}

function sampleTodos(today) {
  const t = Date.now();
  const date = today || shanghaiDateStr();
  return [
    { id: uid(), title: "回复一条重要消息", priority: "urgent", done: false, createdAt: t, sample: true, date },
    { id: uid(), title: "整理今天最想完成的一件事", priority: "high", done: false, createdAt: t + 1, sample: true, date },
    { id: uid(), title: "晚上散步十五分钟", priority: "low", done: false, createdAt: t + 2, sample: true, date },
  ];
}

function emptyRemind() {
  return { on: false, lastNag: "", streak: 0, streakDate: "" };
}

function normalizeRemind(raw) {
  const r = raw && typeof raw === "object" ? raw : {};
  return {
    on: !!r.on,
    lastNag: typeof r.lastNag === "string" ? r.lastNag : "",
    streak: Math.max(0, Number(r.streak) || 0),
    streakDate: isDateStr(r.streakDate) ? r.streakDate : "",
  };
}

function emptyData() {
  const today = shanghaiDateStr();
  return { version: DATA_VERSION, lastDate: today, todos: sampleTodos(today), trash: [], remind: emptyRemind() };
}

function loadRaw() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyData();
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.todos)) return emptyData();
    return data;
  } catch {
    return emptyData();
  }
}

function normalizeTodo(t, i, ctx) {
  const today = ctx.today;
  const lastDate = ctx.lastDate;
  const done = !!t.done;
  const doneDate = isDateStr(t.doneDate) ? t.doneDate : "";
  let date = isDateStr(t.date) ? t.date : "";
  if (!date) {
    date = done ? doneDate || lastDate : today;
  }
  const item = {
    id: t.id || uid(),
    title: String(t.title || "").trim() || "未命名",
    priority: PRIORITIES.some((p) => p.id === t.priority) ? t.priority : "medium",
    done,
    createdAt: Number(t.createdAt) || Date.now() + i,
    sample: !!t.sample,
    date,
  };
  if (done && doneDate) item.doneDate = doneDate;
  return item;
}

function migrate(data) {
  const today = shanghaiDateStr();
  const lastDate = isDateStr(data.lastDate) ? data.lastDate : today;
  const ctx = { today, lastDate };
  data.todos = data.todos.map((t, i) => normalizeTodo(t, i, ctx));
  const cutoff = Date.now() - 14 * 24 * 60 * 60 * 1000;
  data.trash = (Array.isArray(data.trash) ? data.trash : [])
    .map((t, i) => {
      const item = normalizeTodo(t, i, ctx);
      item.deletedAt = Number(t.deletedAt) || Date.now();
      return item;
    })
    .filter((t) => t.deletedAt >= cutoff)
    .slice(-40);
  data.remind = normalizeRemind(data.remind);
  data.version = DATA_VERSION;
  data.lastDate = today;
  return data;
}

function persist(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function load() {
  const data = migrate(loadRaw());
  persist(data);
  return data;
}

function priorityRank(id) {
  const p = PRIORITIES.find((x) => x.id === id);
  return p ? p.rank : 2;
}

function priorityLabel(id) {
  const p = PRIORITIES.find((x) => x.id === id);
  return p ? p.label : "中";
}

function sortTodos(todos, includeDone) {
  const list = includeDone ? todos.slice() : todos.filter((t) => !t.done);
  return list.sort((a, b) => {
    if (includeDone && a.done !== b.done) return a.done ? 1 : -1;
    const pr = priorityRank(a.priority) - priorityRank(b.priority);
    if (pr !== 0) return pr;
    return a.createdAt - b.createdAt;
  });
}

function todosOnDate(date, includeDone) {
  const day = isDateStr(date) ? date : shanghaiDateStr();
  return sortTodos(
    load().todos.filter((t) => t.date === day),
    includeDone
  );
}

function overdueTodos() {
  const today = shanghaiDateStr();
  return sortTodos(
    load().todos.filter((t) => !t.done && t.date < today),
    false
  );
}

function upcomingGroups() {
  const today = shanghaiDateStr();
  const groups = {};
  load().todos.forEach((t) => {
    if (t.done || t.date <= today) return;
    if (!groups[t.date]) groups[t.date] = [];
    groups[t.date].push(t);
  });
  return Object.keys(groups)
    .sort()
    .map((date) => ({ date, items: sortTodos(groups[date], false) }));
}

function overlayTodos() {
  const today = shanghaiDateStr();
  return sortTodos(
    load().todos.filter((t) => !t.done && t.date <= today),
    false
  );
}

function unfinishedOnDate(date) {
  const day = isDateStr(date) ? date : shanghaiDateStr();
  return load().todos.filter((t) => !t.done && t.date === day).length;
}

function nowUnfinishedCount() {
  const today = shanghaiDateStr();
  return load().todos.filter((t) => !t.done && t.date <= today).length;
}

function taskMarks() {
  const marks = {};
  load().todos.forEach((t) => {
    if (!t.date) return;
    if (!marks[t.date]) marks[t.date] = { total: 0, open: 0 };
    marks[t.date].total += 1;
    if (!t.done) marks[t.date].open += 1;
  });
  return marks;
}

function addTodo(title, priority, date) {
  const text = (title || "").trim();
  if (!text) return load();
  const data = load();
  const day = isDateStr(date) ? date : shanghaiDateStr();
  data.todos.push({
    id: uid(),
    title: text,
    priority: PRIORITIES.some((p) => p.id === priority) ? priority : "medium",
    done: false,
    createdAt: Date.now(),
    sample: false,
    date: day,
  });
  persist(data);
  return data;
}

function toggleTodo(id) {
  const data = load();
  const item = data.todos.find((t) => t.id === id);
  if (item) {
    item.done = !item.done;
    if (item.done) {
      item.doneDate = shanghaiDateStr();
      if (!item.sample) touchStreak(data, item.doneDate);
    } else delete item.doneDate;
  }
  persist(data);
  return data;
}

function touchStreak(data, today) {
  const r = normalizeRemind(data.remind);
  if (r.streakDate === today) {
    data.remind = r;
    return r;
  }
  r.streak = r.streakDate === addDays(today, -1) ? r.streak + 1 : 1;
  r.streakDate = today;
  data.remind = r;
  return r;
}

function streakCount(today) {
  const day = isDateStr(today) ? today : shanghaiDateStr();
  const r = normalizeRemind(load().remind);
  if (r.streakDate === day || r.streakDate === addDays(day, -1)) return r.streak;
  return 0;
}

function remindOn() {
  return normalizeRemind(load().remind).on;
}

function setRemindOn(on) {
  const data = load();
  data.remind = normalizeRemind(data.remind);
  data.remind.on = !!on;
  persist(data);
  return data.remind;
}

function nagSlot(state, today) {
  const day = isDateStr(today) ? today : shanghaiDateStr();
  const mood = state && state.mood;
  if (mood === "overdue") return day + "-overdue";
  if (mood === "night") return day + "-night";
  if (mood === "dusk") return day + "-dusk";
  return "";
}

function maybeNag(opts) {
  const data = load();
  const remind = normalizeRemind(data.remind);
  if (!remind.on) return null;
  const state = reminderState(opts);
  const slot = nagSlot(state, shanghaiDateStr(opts && opts.now));
  if (!slot || remind.lastNag === slot) return null;
  remind.lastNag = slot;
  data.remind = remind;
  persist(data);
  const overdue = typeof (opts && opts.overdue) === "number" ? opts.overdue : overdueTodos().length;
  const open = typeof (opts && opts.open) === "number" ? opts.open : nowUnfinishedCount();
  return {
    type: "nag",
    title: "小鲨在催你",
    body: (state.text || "还有没做完的") + (overdue ? " · " + overdue + "件逾期" : " · 还有" + open + "件"),
    slot,
  };
}

function deleteTodo(id) {
  const data = load();
  const item = data.todos.find((t) => t.id === id);
  if (item) {
    if (!Array.isArray(data.trash)) data.trash = [];
    data.trash.push(Object.assign({}, item, { deletedAt: Date.now() }));
    if (data.trash.length > 40) data.trash = data.trash.slice(-40);
    data.todos = data.todos.filter((t) => t.id !== id);
  }
  persist(data);
  return data;
}

function restoreTodo(id) {
  const data = load();
  if (!Array.isArray(data.trash)) data.trash = [];
  const idx = data.trash.findIndex((t) => t.id === id);
  if (idx < 0) return data;
  const item = data.trash[idx];
  data.trash.splice(idx, 1);
  delete item.deletedAt;
  if (data.todos.some((t) => t.id === item.id)) item.id = uid();
  data.todos.push(item);
  persist(data);
  return data;
}

function restoreLast() {
  const data = load();
  const last = (data.trash || [])[data.trash.length - 1];
  if (!last) return data;
  return restoreTodo(last.id);
}

function trashList() {
  return (load().trash || []).slice().reverse();
}

function editTitle(id, title) {
  const text = (title || "").trim();
  const data = load();
  const item = data.todos.find((t) => t.id === id);
  if (item && text) item.title = text;
  persist(data);
  return data;
}

function setTodoPriority(id, priority) {
  const data = load();
  const item = data.todos.find((t) => t.id === id);
  if (item && PRIORITIES.some((p) => p.id === priority)) item.priority = priority;
  persist(data);
  return data;
}

function clearSamples() {
  const data = load();
  data.todos = data.todos.filter((t) => !t.sample);
  persist(data);
  return data;
}

function hasSamples() {
  return load().todos.some((t) => t.sample);
}

function exportJson() {
  const data = load();
  return JSON.stringify(
    {
      version: DATA_VERSION,
      exportedAt: new Date().toISOString(),
      lastDate: data.lastDate,
      todos: data.todos,
      trash: data.trash || [],
      remind: normalizeRemind(data.remind),
    },
    null,
    2
  );
}

function importJson(text) {
  const parsed = JSON.parse(text);
  const todos = Array.isArray(parsed) ? parsed : parsed.todos;
  if (!Array.isArray(todos)) throw new Error("格式不对");
  const today = shanghaiDateStr();
  const lastDate = isDateStr(parsed && parsed.lastDate) ? parsed.lastDate : today;
  const data = {
    version: DATA_VERSION,
    lastDate: today,
    todos: todos.map((t, i) => normalizeTodo(t, i, { today, lastDate })),
    trash: Array.isArray(parsed.trash)
      ? parsed.trash.map((t, i) => {
          const item = normalizeTodo(t, i, { today, lastDate });
          item.deletedAt = Number(t.deletedAt) || Date.now();
          return item;
        })
        : [],
    remind: normalizeRemind(parsed && parsed.remind),
  };
  persist(data);
  return load();
}

function unfinishedCount(date) {
  if (isDateStr(date)) return unfinishedOnDate(date);
  return nowUnfinishedCount();
}

function shanghaiHour(now) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: TZ,
    hour: "numeric",
    hour12: false,
  }).formatToParts(now || new Date());
  const hour = Number((parts.find((p) => p.type === "hour") || {}).value);
  return hour === 24 ? 0 : hour;
}

function reminderState(opts) {
  const o = opts || {};
  const hour = typeof o.hour === "number" ? o.hour : shanghaiHour(o.now);
  const overdue = typeof o.overdue === "number" ? o.overdue : overdueTodos().length;
  const open = typeof o.open === "number" ? o.open : nowUnfinishedCount();
  if (open <= 0) return { mood: "done", hour, text: "都做完了" };
  if (overdue > 0) return { mood: "overdue", hour, text: "有逾期" };
  if (hour >= 21) return { mood: "night", hour, text: "还没做完" };
  if (hour >= 17) return { mood: "dusk", hour, text: "天快晚了" };
  return { mood: "idle", hour, text: "" };
}

function petSpeech(opts) {
  const state = reminderState(opts);
  const streak = typeof (opts && opts.streak) === "number" ? opts.streak : streakCount();
  const lines = {
    idle: streak ? "连续" + streak + "天了，先做一件。" : "今天从一件开始。",
    dusk: "天快晚了，先做最要紧的一件。",
    night: "还没做完。小鲨陪着。",
    overdue: "有逾期。先把过期的勾掉。",
    done: streak ? "都做完了。连续" + streak + "天。" : "都做完了。",
  };
  return Object.assign({}, state, { speech: lines[state.mood] || state.text, streak });
}

const PET_STYLE_KEY = "jinri-pet-style";
const PET_STYLES = {
  "3d": {
    idle: "icons/face3d-idle.png",
    dusk: "icons/face3d-dusk.png",
    night: "icons/face3d-night.png",
    overdue: "icons/face3d-overdue.png",
    done: "icons/face3d-done.png",
    poke: "icons/face3d-poke.png",
  },
  pixel: {
    idle: "icons/facepx-idle.png",
    dusk: "icons/facepx-dusk.png",
    night: "icons/facepx-night.png",
    overdue: "icons/facepx-overdue.png",
    done: "icons/facepx-done.png",
    poke: "icons/facepx-poke.png",
  },
};
const PET_FACES = PET_STYLES["3d"];

function petStyle() {
  try {
    return localStorage.getItem(PET_STYLE_KEY) === "pixel" ? "pixel" : "3d";
  } catch (e) {
    return "3d";
  }
}

function setPetStyle(style) {
  const next = style === "pixel" ? "pixel" : "3d";
  try {
    localStorage.setItem(PET_STYLE_KEY, next);
  } catch (e) {}
  return next;
}

function petFaceSrc(mood, style) {
  const pack = PET_STYLES[style || petStyle()] || PET_STYLES["3d"];
  return pack[mood] || pack.idle;
}

const JinriAPI = {
  STORAGE_KEY,
  DATA_VERSION,
  PRIORITIES,
  WEEKDAYS,
  shanghaiDateStr,
  isDateStr,
  yearMonth,
  addDays,
  addMonths,
  formatHeaderDate,
  formatShortDate,
  formatMonthTitle,
  weekCells,
  monthCells,
  load,
  persist,
  sortTodos,
  todosOnDate,
  overdueTodos,
  upcomingGroups,
  overlayTodos,
  unfinishedOnDate,
  nowUnfinishedCount,
  taskMarks,
  addTodo,
  toggleTodo,
  deleteTodo,
  restoreTodo,
  restoreLast,
  trashList,
  editTitle,
  setTodoPriority,
  clearSamples,
  hasSamples,
  exportJson,
  importJson,
  unfinishedCount,
  priorityLabel,
  shanghaiHour,
  reminderState,
  petSpeech,
  PET_STYLE_KEY,
  PET_STYLES,
  PET_FACES,
  petStyle,
  setPetStyle,
  petFaceSrc,
  streakCount,
  remindOn,
  setRemindOn,
  nagSlot,
  maybeNag,
};

root.Jinri = JinriAPI;
if (typeof module !== "undefined" && module.exports) module.exports = JinriAPI;
})(typeof window !== "undefined" ? window : globalThis);
